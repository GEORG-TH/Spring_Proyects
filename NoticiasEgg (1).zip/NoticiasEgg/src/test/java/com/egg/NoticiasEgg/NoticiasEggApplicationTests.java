package com.egg.NoticiasEgg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoticiasEggApplicationTests {

	@Test
	void contextLoads() {
	}

}
